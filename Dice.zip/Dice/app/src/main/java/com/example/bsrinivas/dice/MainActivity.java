package com.example.bsrinivas.dice;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int[] mydice={R.drawable.two,R.drawable.three,R.drawable.four,R.drawable.five,R.drawable.one,R.drawable.six};
    public void role(View view) {
       // Toast.makeText(this,"clicked", Toast.LENGTH_SHORT).show();
        Random ram= new Random();
        int randomnumber=ram.nextInt(6);
        //to display in logcat
        //log.i("random","random number is"+randomnumber);
        ImageView dice= (ImageView) findViewById(R.id.dice);
        dice.setImageResource(mydice[randomnumber]);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}
